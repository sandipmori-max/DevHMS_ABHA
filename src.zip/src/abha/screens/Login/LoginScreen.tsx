import React, { useEffect, useMemo, useState } from 'react';
import {
  View,
  Text,
  SafeAreaView,
  TouchableOpacity,
  TextInput,
  ScrollView,
  KeyboardAvoidingView,
  Platform,
  TouchableWithoutFeedback,
  Keyboard,
} from 'react-native';
import { useNavigation, useRoute } from '@react-navigation/native';
import { encryptData } from '../../utils/encrypt';
import { useDispatch, useSelector } from 'react-redux';
import { getPayload, useRequestOtpMutation } from '../../redux/api/loginApi';
import { hideLoader, showLoader } from '../../redux/slices/loaderSlice';
import { showToast } from '../../utils/toast';
import MaterialIcons from "@react-native-vector-icons/material-icons";
import { getEnrollmentPayload, useEnrollmentRequestOtpMutation } from '../../redux/api/enrollmentApi';
import { getEmailVerificationLinkPayload, useRequestEmailVerificationLinkMutation } from '../../redux/api/emailVerificationLinkApi';
import { useEnrolSuggestionMutation } from '../../redux/api/enrolSuggestionApi';
import DLStepTwo from './DLStepTwo';
import { styles } from './style';
import RadioItem from './RadioItem';
import { formatLoginInput, getIsFormValid, getLoginKeyboardType, getLoginMaxLength, getLoginPlaceholder, isStrictIndianMobile, steps, stepsDL, validateForm } from '../../utils/helpers';
import StepOne from './StepOne';
import StepTwo from './StepTwo';
import StepThree from './StepThree';
import StepFour from './StepFour';
import DLStepOne from './DLStepOne';
import { getDlEnrollmentRequestOtpPayload, useDlEnrollmentRequestOtpMutation } from '../../redux/api/dlEnrollmentRequestOtpApi';
import ValidationErrorBottomSheet from './ValidationErrorBottomSheet';
import { LOGIN_TYPES } from '../../utils/constants';
import TermsConditions from './TermsConditions';
import AadhaarInput from './AadhaarInput';
import ValidationOptions from './ValidationOptions';
import { useLoginFlow } from './useLoginFlow';
import { useSearchAbhaAddressMutation } from '../../redux/api/abhaSearchApi';
import { useAbhaAddressRequestOtpMutation } from '../../redux/api/abhaAddressLoginApi';
import { isValidAadhaar } from '../../utils/aadhaarValidator';
import { ERP_COLOR_CODE } from '../../../utils/constants';
import ABHACard from './ABHACard';
import { useCreateSessionMutation } from '../../redux/api/sessionApi';

const LoginScreen = () => {
  const navigation = useNavigation<any>();
  const route = useRoute<any>();

  const dispatch = useDispatch()

  const publicKey = useSelector(
    (state: any) => state.abhaauth.publicKey
  );

  console.log("publicKeypublicKeypublicKey", publicKey)
  const { txnId } = useSelector((state: any) => state.abha);
  const { loginType, isFromRegister = false, isFromCreate = false, isFromMobileRegister = false, isFromForgotAbhaNumber = false, isFromForgotAbhaNumberWithType = false, } = route.params ?? {};


  const [searchProfile, setSearchProfile] = useState()
  const [showSearchProfile, setShowSearchProfile] = useState(false)
  const {
    stepOne, setStepOne, stepTwo, setStepTwo, stepThree, setStepThree, stepFour,
    stepOneDL, setStepOneDL, currentStep, setCurrentStep,
    currentStepDL, setCurrentStepDL,
    loginValue, setLoginValue,
    password, setPassword,
    showPassword, setShowPassword,
    validationMethod, setValidationMethod,
    otpMethod, setOtpMethod,
    isAgreed, setIsAgreed,
    captcha, captchaValue, setCaptchaValue,
    refreshCaptcha, selectedItem,
    abhaSuggestionList, setAbhaSuggestionList,
    showValidationSheet, setShowValidationSheet,
    validationErrors, setValidationErrors,
    stepTwoRef, handleSelect, handleSteps, handleOTPVerify,
    shouldShowTerms, termsText, validationConfig,
  } = useLoginFlow({
    loginType, isFromRegister, isFromCreate, isFromMobileRegister, isFromForgotAbhaNumber, isFromForgotAbhaNumberWithType,
  });

  const [requestOtp] = useRequestOtpMutation();
  const [
    createSession
  ] = useCreateSessionMutation();
  const [
    searchAbhaAddress,
    {
      isLoading
    }
  ] = useSearchAbhaAddressMutation();
  const [enrollmentRequestOtp,] = useEnrollmentRequestOtpMutation();
  const [
    abhaAddressRequestOtp
  ] = useAbhaAddressRequestOtpMutation();
  const [requestEmailVerificationLink,] = useRequestEmailVerificationLinkMutation();
  const [enrolSuggestion,] = useEnrolSuggestionMutation();
  const [dlEnrollmentRequestOtp,] = useDlEnrollmentRequestOtpMutation();

  const placeholder = useMemo(
    () => getLoginPlaceholder(loginType),
    [loginType]
  );

  const maxLength = useMemo(() => getLoginMaxLength(loginType),
    [loginType]
  )

  const renderStep = () => {
    switch (currentStep) {
      case 1:
        return <>
          <StepOne
            captcha={captcha}
            captchaValue={captchaValue}
            stepOne={stepOne}
            setStepOne={setStepOne}
            loginType={loginType}
            validationMethod={validationMethod}
            setLoginValue={setLoginValue}
            refreshCaptcha={refreshCaptcha}
            setCaptchaValue={setCaptchaValue}
            setValidationMethod={setValidationMethod}
          />
        </>;

      case 2:
        return <>
          <StepTwo
            setStepTwo={setStepTwo}
            stepTwo={stepTwo}
            loginType={loginType}
            loginValue={loginValue}
            publicKey={publicKey}
            txnId={txnId}
          />
        </>;

      case 3:
        return <>
          <StepThree
            requestEmailVerificationLink={requestEmailVerificationLink}
            enrolSuggestion={enrolSuggestion}
            setAbhaSuggestionList={setAbhaSuggestionList}
            setCurrentStep={setCurrentStep}
            stepThree={stepThree}
            setStepThree={setStepThree}
            loginType={loginType}
            publicKey={publicKey}
            txnId={txnId}
            enrollmentRequestOtp={enrollmentRequestOtp}
            getEmailVerificationLinkPayload={getEmailVerificationLinkPayload}
            mobileNumer={stepTwo?.stepTwoMobileNumber}
            setValidationErrors={setValidationErrors}
            setShowValidationSheet={setShowValidationSheet}
          />
        </>

      case 4:
        return <>
          <StepFour
            stepFour={stepFour}
            loginType={loginType}
            abhaSuggestionList={abhaSuggestionList}
            selectedItem={selectedItem}
            handleSelect={handleSelect}
            setValidationErrors={setValidationErrors}
            showValidationSheet={showValidationSheet}
          />
        </>;
      default:
        return null;
    }
  };

  const renderDLStep = () => {
    switch (currentStepDL) {
      case 1:
        return <>
          <DLStepOne
            refreshCaptcha={refreshCaptcha}
            stepOneDL={stepOneDL}
            setStepOneDL={setStepOneDL}
            setCurrentStepDL={setCurrentStepDL}
            loginType={loginType}
            captcha={captcha}
            captchaValue={captchaValue}
            setCaptchaValue={setCaptchaValue}
            handleOTPVerify={handleOTPVerify}
          />
        </>;
      case 2:
        return <><DLStepTwo
          ref={stepTwoRef}
          mobileNumber={stepOneDL?.stepOneDLMobileNumber} /></>;
      case 3:
        return <></>
    }
  }

  const headerTitle = useMemo(() => {
    if (isFromForgotAbhaNumber) {
      return "Recover ABHA Number";
    }

    if (isFromRegister) {
      return loginType === LOGIN_TYPES.AADHAAR
        ? "Create ABHA Number Using Aadhaar"
        : "Create ABHA Number Using Driving Licence";
    }

    if (isFromCreate || isFromMobileRegister) {
      return loginType;
    }

    return "Welcome Back 👋";
  }, [
    loginType,
    isFromRegister,
    isFromCreate,
    isFromMobileRegister,
    isFromForgotAbhaNumber,
  ]);


  const getPayloadData = (type, encryptedValue) => {
    switch (type) {
      case "Aadhaar OTP":
        return {

          scope: [
            "abha-address-login",
            "aadhaar-verify"
          ],
          loginHint: "abha-address",
          loginId: encryptedValue,
          otpSystem: "aadhaar",
        };

      case "Mobile OTP":
        return {
          scope: [
            "abha-address-login",
            "mobile-verify"
          ],
          loginHint: "abha-address",
          loginId: encryptedValue,
          otpSystem: "abdm",
        };
    }
  }
  return (
    <SafeAreaView style={styles.container}>
      <KeyboardAvoidingView
        style={{ flex: 1 }}
        behavior={Platform.OS === 'ios' ? 'padding' : undefined}
      >
        {
          isFromRegister ? <>
            <View style={styles.header}>
              <View style={{ flexDirection: 'row' }}>
                <TouchableOpacity
                  onPress={() =>
                    navigation.goBack()
                  }
                  style={{ marginVertical: 4 }}
                >
                  <MaterialIcons
                    name='arrow-back'
                    size={20}
                  />
                </TouchableOpacity>

                {
                  headerTitle !== 'Welcome Back 👋' && <View style={{
                    marginLeft: 18,
                    justifyContent: 'center',
                    alignContent: 'center',
                    alignItems: 'center',
                    flexDirection: 'row', gap: 8
                  }}>

                    <View style={[
                      {
                        borderRadius: 4,
                        alignContent: 'center',
                        alignItems: 'center',
                        alignSelf: 'center',
                      }
                    ]}>
                      <Text style={[styles.typeText, {
                        color: 'black'
                      }]}>
                        {headerTitle}

                      </Text>
                    </View>
                  </View>
                }

              </View>


              <Text style={[styles.welcome,
              {
                color: ERP_COLOR_CODE.ERP_APP_COLOR
              },
              isFromRegister && {
                fontSize: 18
              }]}>
                {steps[currentStep - 1]}
              </Text>

            </View>
          </> : <View style={styles.header}>
            <TouchableOpacity
              onPress={() =>
                navigation.goBack()
              }
              style={{ marginVertical: 4 }}
            >
              <MaterialIcons
                name='arrow-back'
                size={20}
              />
            </TouchableOpacity>

            <Text style={[styles.welcome, isFromRegister && {
              fontSize: 18
            }]}>
              {headerTitle}
            </Text>
          </View>
        }

        {
          isFromRegister ? <>
            <View style={{ height: '85%' }}>
              {
                loginType === 'Aadhaar Number' ? <>
                  <View style={styles.stepContainer}>
                    {steps.map((item, index) => {
                      const stepNumber = index + 1;
                      const isActive = currentStep >= stepNumber;
                      return (
                        <React.Fragment key={index}>
                          <TouchableOpacity
                            style={styles.stepItem}
                            disabled
                          >
                            <View
                              style={[
                                styles.circle,
                                isActive && styles.activeCircle,
                                isActive && {
                                  backgroundColor: ERP_COLOR_CODE.ERP_APP_COLOR
                                },
                              ]}
                            >
                              <Text
                                style={[
                                  styles.circleText,
                                  isActive && styles.activeCircleText,
                                ]}
                              >
                                {stepNumber}
                              </Text>
                            </View>

                            <Text
                              style={[
                                styles.stepLabel,
                                isActive && styles.activeStepLabel,
                              ]}
                            >
                              Step {stepNumber}
                            </Text>
                          </TouchableOpacity>
                          {index < steps.length - 1 && (
                            <View
                              style={[
                                styles.line,
                                currentStep > stepNumber && styles.activeLine,
                              ]}
                            />
                          )}
                        </React.Fragment>
                      );
                    })}
                  </View>
                  <ScrollView
                    showsVerticalScrollIndicator={false}
                    style={{ flex: 0.8, padding: 0 }}>
                    {renderStep()}
                  </ScrollView>
                  <View style={[styles.buttonContainer, {
                  }]}>
                    <View />
                    <TouchableOpacity
                      onPress={async () => {
                        handleSteps()
                      }}
                      style={[styles.nextButton, {
                        backgroundColor: ERP_COLOR_CODE.ERP_APP_COLOR
                      }]}
                    >
                      <Text style={{ color: '#FFF', fontWeight: '600', fontSize: 16 }}>
                        {currentStep === 4 ? 'Create ABHA' : currentStep === 3 ?
                          stepThree.stepThreeMobileAuthDone ?
                            "Skip for now" : "Next" : 'Next'}
                      </Text>
                    </TouchableOpacity>
                  </View>
                </> :
                  <>
                    <View style={styles.stepContainer}>
                      {stepsDL.map((item, index) => {
                        const stepNumber = index + 1;
                        const isActive = currentStepDL >= stepNumber;
                        return (
                          <React.Fragment key={index}>
                            <TouchableOpacity
                              style={styles.stepItem}
                              disabled
                            >
                              <View
                                style={[
                                  styles.circle,
                                  isActive && styles.activeCircle,
                                ]}
                              >
                                <Text
                                  style={[
                                    styles.circleText,
                                    isActive && styles.activeCircleText,
                                  ]}
                                >
                                  {stepNumber}
                                </Text>
                              </View>

                              <Text
                                style={[
                                  styles.stepLabel,
                                  isActive && styles.activeStepLabel,
                                ]}
                              >
                                Step {stepNumber}
                              </Text>
                            </TouchableOpacity>

                            {index < stepsDL.length - 1 && (
                              <View
                                style={[
                                  styles.line,
                                  currentStep > stepNumber && styles.activeLine,
                                ]}
                              />
                            )}
                          </React.Fragment>
                        );
                      })}

                    </View>
                    <ScrollView
                      showsVerticalScrollIndicator={false}
                      style={{ flex: 0.8, padding: 0 }}>
                      {renderDLStep()}
                    </ScrollView>

                    <View style={[styles.buttonContainer]}>
                      <View style={[
                        {
                          backgroundColor: '#173D8F',
                          borderRadius: 4,
                          alignContent: 'center',
                          alignItems: 'center',
                          alignSelf: 'center',
                          padding: 10
                        }
                      ]}>
                        <Text style={styles.typeText}>
                          {stepsDL[currentStepDL - 1]}
                        </Text>
                      </View>

                      {
                        !stepOneDL.stepOneDLMobileVerifying && <TouchableOpacity
                          onPress={async () => {
                            try {
                              dispatch(showLoader())
                              if (currentStepDL === 1) {
                                if (stepOneDL.stepOneDLMobileNumber === '' && !stepOneDL.stepOneDLMobileVerifying) {
                                  showToast('error', 'Please enter your mobile number.')
                                  return;
                                }
                                const isNumberValid = isStrictIndianMobile(`+91${stepOneDL.stepOneDLMobileNumber}`)
                                if (!isNumberValid) {
                                  showToast('error', 'Please enter a valid mobile number.')
                                  return;
                                }
                                if (!captchaValue) {
                                  showToast('error', 'Please enter the CAPTCHA.')
                                  return;
                                }
                                if (Number(captchaValue) !== captcha.answer) {
                                  showToast('error', 'Please enter a valid CAPTCHA.')
                                  return;
                                }
                                const encryptedMobile = encryptData(
                                  stepOneDL.stepOneDLMobileNumber,
                                  publicKey,
                                );
                                const payload =
                                  getDlEnrollmentRequestOtpPayload(
                                    encryptedMobile
                                  );

                                const response =
                                  await dlEnrollmentRequestOtp(
                                    payload
                                  ).unwrap();
                                showToast('success', response?.message)
                                setStepOneDL({
                                  ...stepOneDL,
                                  stepOneDLTitle: response?.message,
                                  stepOneDLMobileVerifying: true,
                                });
                              } else if (currentStepDL === 2) {
                                const result = stepTwoRef.current?.validateForm();
                                if (!result.isValid) {
                                  setValidationErrors(result.errors);
                                  setShowValidationSheet(true); // Bottom Sheet open
                                  return;
                                }
                                console.log(result.data);
                              }
                            } catch (error) {
                              showToast('error', `${error}`)
                              dispatch(hideLoader())
                            } finally {
                              dispatch(hideLoader())
                            }
                          }}
                          style={[styles.nextButton, {
                            backgroundColor: ERP_COLOR_CODE.ERP_APP_COLOR
                          }]}
                        >
                          <Text style={{ color: '#FFF' }}>
                            {'Next'}
                          </Text>
                        </TouchableOpacity>
                      }
                    </View>
                  </>
              }
            </View>
          </> : <>
            <ScrollView
              showsVerticalScrollIndicator={false}
              contentContainerStyle={{
                paddingBottom: 140,
              }}
            >
              <View style={styles.hero}>
                {
                  !isFromForgotAbhaNumber && !isFromMobileRegister && !isFromCreate && !isFromRegister && <Text style={styles.subtitle}>
                    Sign in securely to access
                    your ABHA health records
                  </Text>
                }
                {
                  isFromForgotAbhaNumber && <Text style={styles.subtitle}>
                    You can recover your ABHA number using Aadhaar number or registered mobile number. Recovery using any of the following methods requires filling out your basic details and access to your linked mobile.
                  </Text>
                }
              </View>
              <View style={{
                width: '94%',
                alignContent: 'center',
                alignItems: 'center',
                flexDirection: 'row',
                justifyContent: 'space-between'
              }}>
                {
                  isFromRegister ? <View style={{ marginVertical: 1 }}></View> :
                    <>
                      {
                        !isFromForgotAbhaNumber && !isFromMobileRegister && !isFromCreate && <View style={styles.typeChip}>
                          <Text style={styles.typeText}>
                            {loginType}
                          </Text>
                        </View>
                      }
                    </>
                }
              </View>
              {
                !isFromForgotAbhaNumber && <View style={styles.card}>
                  {
                    <Text style={styles.cardTitle}>
                      {loginType} <Text style={{ color: 'red' }}>*</Text>
                    </Text>
                  }
                  <View style={[styles.inputContainer, loginType === 'Aadhaar Number' && {
                    backgroundColor: '#fff',
                    borderColor: '#fff'
                  }]}>
                    {(loginType === LOGIN_TYPES.MOBILE ||
                      loginType === 'Register with Mobile Number') && (
                        <Text style={styles.prefix}>+91</Text>
                      )}
                    {
                      loginType === 'Aadhaar Number' ?
                        <>
                          <AadhaarInput
                            value={loginValue}
                            onChange={setLoginValue}
                          />

                        </> : <>  <TextInput
                          editable={showSearchProfile ? false : true}
                          value={loginValue}
                          onChangeText={text => {
                            setLoginValue(formatLoginInput(loginType, text))
                          }}
                          placeholder={placeholder}
                          placeholderTextColor="#999999"
                          maxLength={maxLength}
                          keyboardType={getLoginKeyboardType(loginType)}
                          style={styles.input}
                        /> </>
                    }


                    {
                      loginType === 'ABHA Address' && <Text style={styles.hintText}>
                        abdm
                      </Text>
                    }
                  </View>
                  {
                    loginType === 'Aadhaar Number' && <View style={{
                      marginVertical: 4,
                      flexDirection: 'row'

                    }}>
                      <MaterialIcons name='info-outline' color={'#869bea'} style={{ marginRight: 4 }} />
                      <Text style={{
                        color: '#869bea'
                      }}>Please ensure that mobile number is linked with Aadhaar as it will be required for OTP authentication.</Text>
                    </View>
                  }

                  {/* {
                    <TouchableOpacity
                      onPress={() => {
                        setValidationMethod('')
                        setTimeout(() => {
                          setValidationMethod('Aadhaar Number')
                          setLoginValue("")
                          setCaptchaValue("")
                          refreshCaptcha()
                          setIsAgreed(false)
                          Keyboard.dismiss()
                          navigation.navigate("RegistrationAbha", {
                            loginType: 'Forgot ABHA Number',
                            isFromRegister: false,
                            isFromCreate: false,
                            isFromMobileRegister: false,
                            isFromForgotAbhaNumber: true
                          })
                        })
                      }}>
                      <Text style={[styles.forgotText, {
                        alignSelf: 'flex-end',
                        marginTop: 10
                      }]}>
                        Forgot ABHA number?
                      </Text>
                    </TouchableOpacity>
                  } */}
                </View>
              }
              {
                isFromForgotAbhaNumberWithType && <View style={styles.card}>
                  <Text style={styles.cardTitle}>
                    Enter Details <Text style={{ color: 'red' }}>*</Text>
                  </Text>
                  <View style={styles.inputContainer}>
                    <TextInput
                      value={loginValue}
                      onChangeText={text => {
                        setLoginValue(formatLoginInput(loginType, text))
                      }}
                      placeholder={placeholder}
                      maxLength={maxLength}
                      keyboardType={getLoginKeyboardType(loginType)}
                      style={styles.input}
                      placeholderTextColor="#999999"
                    />

                  </View>
                </View>
              }
              {loginType === 'Forgot ABHA Number' && <ValidationOptions
                options={validationConfig[loginType] ?? []}
                value={validationMethod}
                onChange={(item) => {
                  setValidationMethod(item);
                  setOtpMethod("");
                }}
              />}
              {
                isFromForgotAbhaNumber && <View style={styles.card}>
                  <Text style={styles.cardTitle}>
                    Enter Details <Text style={{ color: 'red' }}>*</Text>
                  </Text>
                  <View style={styles.inputContainer}>
                    {(validationMethod === LOGIN_TYPES.MOBILE ||
                      validationMethod === 'Register with Mobile Number') && (
                        <Text style={styles.prefix}>+91</Text>
                      )}
                    <TextInput
                      value={loginValue}
                      onChangeText={text => {
                        setLoginValue(formatLoginInput(validationMethod, text))
                      }}
                      placeholder={validationMethod === LOGIN_TYPES.MOBILE ? 'Enter mobile number' : 'Enter aadhaar number'}
                      maxLength={maxLength}
                      keyboardType={getLoginKeyboardType(validationMethod)}
                      style={styles.input}
                      placeholderTextColor="#999999"
                    />

                  </View>
                </View>
              }

              {validationMethod === 'Password' && (
                <View style={styles.card}>
                  <Text style={styles.cardTitle}>
                    Password
                  </Text>
                  <View style={styles.passwordContainer}>
                    <TextInput
                      secureTextEntry={!showPassword}
                      value={password}
                      onChangeText={setPassword}
                      placeholder="Enter Password"
                      style={styles.passwordInput}
                      placeholderTextColor="#999999"
                    />
                    <TouchableOpacity
                      onPress={() =>
                        setShowPassword(
                          !showPassword,
                        )
                      }
                    >
                      <Text style={styles.eyeIcon}>
                        {showPassword
                          ? '🙈'
                          : '👁️'}
                      </Text>
                    </TouchableOpacity>
                  </View>
                </View>
              )}

              {validationMethod === 'Face Auth' && (
                <View style={styles.faceAuthCard}>
                  <Text style={styles.faceEmoji}>
                    😊
                  </Text>

                  <Text style={styles.faceText}>
                    Face Authentication will be used
                    for verification
                  </Text>
                </View>
              )}

              {
                showSearchProfile && <ABHACard abhaData={searchProfile} />
              }

              {loginType === 'ABHA Address' && (
                <View style={styles.card}>
                  <Text style={styles.cardTitle}>
                    Validate Using <Text style={{ color: 'red' }}>*</Text>
                  </Text>

                  <View style={{ flexDirection: 'row' }}>
                    <RadioItem
                      title="Aadhaar OTP"
                      selected={otpMethod === 'Aadhaar OTP'}
                      onPress={() =>
                        setOtpMethod(
                          'Aadhaar OTP',
                        )
                      }
                    />
                    <View style={{ width: 18 }} />
                    <RadioItem
                      title="Mobile OTP"
                      selected={otpMethod === 'Mobile OTP'}
                      onPress={() =>
                        setOtpMethod(
                          'Mobile OTP',
                        )
                      }
                    />
                  </View>
                </View>
              )}

              {shouldShowTerms && (
                <TermsConditions
                  text={termsText}
                  checked={isAgreed}
                  onToggle={() => setIsAgreed(prev => !prev)}
                />
              )}

              <View style={{ marginHorizontal: 24, marginVertical: 2, backgroundColor: 'white', padding: 16, borderRadius: 8 }}>
                <View>
                  <Text style={styles.cardTitle}>Captcha <Text style={{ color: 'red' }}>*</Text></Text>
                </View>
                <View style={styles.captchaContainer}>

                  <Text style={styles.captchaText}>
                    {captcha.question}
                  </Text>

                  <TextInput
                    placeholder="Enter answer"
                    keyboardType="number-pad"
                    value={captchaValue}
                    onChangeText={setCaptchaValue}
                    style={styles.captchaInput}
                    placeholderTextColor="#999999"
                  />

                  <TouchableOpacity onPress={refreshCaptcha}>
                    <MaterialIcons
                      name="loop"
                      size={28}
                      color="#1E40AF"
                    />

                  </TouchableOpacity>
                </View>
              </View>
            </ScrollView>
            <View style={styles.bottomBar}>
              <TouchableOpacity
                style={[
                  styles.continueBtn,
                  {
                    backgroundColor: ERP_COLOR_CODE.ERP_APP_COLOR
                  }
                ]}
                onPress={async () => {
                  try {

                    if (loginType === 'ABHA Address' && showSearchProfile && searchProfile) {
                      await createSession()
                        .unwrap();
                      const encryptedValue = encryptData(searchProfile?.abhaAddress, publicKey,);

                      const payload: any = getPayloadData(otpMethod, encryptedValue)
                      console.log("payload + + + + + + getPayloadData + + + + ", payload)
                      const result = await abhaAddressRequestOtp(payload).unwrap();

                      console.log("result+++++++++++++++", result)
                      showToast(
                        "success",
                        result?.message || "OTP sent successfully"
                      );
                      setTimeout(() => {
                        navigation.replace('OtpVerification', {
                          loginType,
                          mobileNumber: loginValue,
                          loginValue: loginValue,
                          txnId: txnId,
                          otpMethod: otpMethod,
                          result: result,
                          payload: payload
                        });


                      }, 1000);
                      return;
                    }
                    const errors = validateForm(
                      loginType,
                      loginValue,
                      isFromForgotAbhaNumber,
                      isAgreed,
                      captchaValue,
                      captcha,
                      otpMethod
                    );

                    if (errors.length > 0) {
                      setValidationErrors(errors);
                      setShowValidationSheet(true)
                      return;
                    }

                    setValidationErrors([]);
                    if (loginType === 'Aadhaar Number' && loginValue && loginValue.length === 12 && !isValidAadhaar(loginValue)) {
                      showToast(
                        "error",
                        "Please enter a valid Aadhaar number."
                      );
                      return;
                    } else if (loginType === 'Mobile Number' && loginValue && loginValue.length === 10 && !isStrictIndianMobile(
                      `+91${loginValue}`
                    )) {
                      showToast(
                        "error",
                        "Please enter a valid mobile number."
                      );
                      return;
                    }
                    dispatch(showLoader());
                    if (isFromRegister) {
                      await createSession()
                        .unwrap();
                      const encryptedValue = encryptData(loginValue, publicKey,);
                      const payloadPassed = getEnrollmentPayload(loginType, encryptedValue, txnId,);
                      const result = await enrollmentRequestOtp(payloadPassed).unwrap();
                      showToast(
                        "success",
                        result?.message || "OTP sent successfully"
                      );
                      setTimeout(() => {
                        navigation.replace('OtpVerification', {
                          loginType,
                          mobileNumber: loginValue,
                        });
                      }, 1000);
                    } else {

                      if (loginType === 'ABHA Address') {


                        const response =
                          await searchAbhaAddress({
                            abhaAddress:
                              loginValue
                          }).unwrap();


                        console.log(
                          "SUCCESS => + + + + + + + + + + + + + +",
                          response
                        );
                        setShowSearchProfile(true)
                        setSearchProfile(response)

                        return;


                      } else {
                        await createSession()
                          .unwrap();
                        console.log("publicKeypublicKeypublicKey", publicKey)
                        const encryptedValue = encryptData(loginValue, publicKey,);
                        const payloadPassed = getPayload(
                          loginType === 'Forgot ABHA Number' ? validationMethod : loginType,
                          encryptedValue,
                          txnId,
                        );
                        const result = await requestOtp(payloadPassed).unwrap();
                        showToast(
                          "success",
                          result?.message || "OTP sent successfully"
                        );
                        setTimeout(() => {
                          navigation.replace('OtpVerification', {
                            loginType,
                            mobileNumber: loginValue,
                            loginValue: loginValue,
                            txnId: txnId,
                            validationMethod: validationMethod,
                            result: result
                          });
                        }, 1000);
                      }

                    }
                  } catch (error) {
                    console.log("error -------------- ", error)
                    dispatch(hideLoader());
                  } finally {
                    dispatch(hideLoader());
                  }
                }}
              >
                <Text style={styles.continueText}>
                  {
                    loginType === 'ABHA Address' && !showSearchProfile ? 'Search' : isFromCreate ? "Next" : "Continue"
                  }

                </Text>
              </TouchableOpacity>


            </View></>
        }
        {
          validationErrors && <ValidationErrorBottomSheet
            visible={showValidationSheet}
            errors={validationErrors}
            onClose={() => setShowValidationSheet(false)}
          />
        }

      </KeyboardAvoidingView>
    </SafeAreaView>
  );
};

export default LoginScreen;
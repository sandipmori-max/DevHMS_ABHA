import { Dimensions, Platform, StyleSheet } from 'react-native';
import { ERP_COLOR_CODE } from '../../utils/constants';

export const styles = StyleSheet.create({
  header: {
    top: 38,
    padding: 10,
    alignItems: 'center',
    backgroundColor: ERP_COLOR_CODE.ERP_APP_COLOR,
    borderRadius: 8
  },
  profileImage: {
    width: 80,
    height: 80,
    borderRadius: 10,
    marginBottom: 10,
    backgroundColor: ERP_COLOR_CODE.ERP_APP_COLOR,
    borderWidth: 2,
    top: -55,
    left: -40,
    position:'absolute',
    borderColor: ERP_COLOR_CODE.ERP_WHITE
  },
  username: {
    color: ERP_COLOR_CODE.ERP_WHITE,
    fontSize: 18,
    fontWeight: 'bold',
  },

  userPhone: {
    color: '#FFF',
    fontSize: 12,
    marginLeft: 6,
  },
  emailid:{
        color: '#FFF',
  },
  menuContainer: {
    height: Dimensions.get("screen").height * 0.52,
    paddingTop: 10,
    top: 30
  },
  itemRow: {
    flexDirection: 'row',
    alignItems: 'center',
    margin: Platform.OS === 'android' ? 6 :8,
  },
  itemIcon: {
    fontSize: 18,
    marginRight: 10,
  },
  itemLabel: {
    marginLeft: 12,
    fontSize: 14, 
  },
  activeText: {
    color: ERP_COLOR_CODE.ERP_007AFF,
    fontWeight: 'bold',
     fontSize: 16,
  },
  drawerItem: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    borderRadius: 8,
    marginHorizontal: 8,
    marginVertical: 2,
    borderWidth: 0.5,
    borderColor: ERP_COLOR_CODE.ERP_BORDER_LINE
  },
  activeItemBackground: {
    backgroundColor: ERP_COLOR_CODE.ERP_APP_COLOR,
    borderLeftWidth: 4,
    borderLeftColor: ERP_COLOR_CODE.ERP_APP_COLOR,
    borderRadius: 8,
  },
  logoutButton: {
    paddingHorizontal: 20,
    paddingVertical: 4,
    borderTopWidth: 1,
    borderColor: ERP_COLOR_CODE.ERP_APP_COLOR,
    alignContent: 'center',
    alignItems: 'center',
  },
  logoutText: {
    fontWeight: 'bold',
    color: ERP_COLOR_CODE.ERP_APP_COLOR,
  },
  
});

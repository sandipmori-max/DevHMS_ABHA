import React, { useCallback, useEffect, useRef, useState } from "react";
import {
  Text,
  Image,
  Animated,
  View,
  Platform,
  useWindowDimensions,
} from "react-native";
import { useFocusEffect } from "@react-navigation/native";

import { ERP_GIF, ERP_ICON } from "../../assets";
import { styles } from "./error_style";
import { ErrorMessageProps } from "../types";
import { useAppSelector } from "../../store/hooks";
import { ERP_COLOR_CODE } from "../../utils/constants";

const ErrorMessage: React.FC<ErrorMessageProps> = ({
  message,
  visible = true,
  isShowTop = true,
}) => {

  const theme = useAppSelector((state) => state?.theme.mode);

  const opacity = useRef(new Animated.Value(0)).current;
  const imageTranslateX = useRef(new Animated.Value(-15)).current;
  const textTranslateX = useRef(new Animated.Value(15)).current;
  
  const [shouldRender, setShouldRender] = useState(false);

  useFocusEffect(
    useCallback(() => {
      opacity.setValue(0);
      imageTranslateX.setValue(-150);
      textTranslateX.setValue(150);

      return () => {
        setShouldRender(false);
      };
    }, []),
  );

  // 🎬 Animate on visible/message change
  useEffect(() => {
    if (visible && message) {
      setShouldRender(true);

      Animated.parallel([
        Animated.timing(opacity, {
          toValue: 1,
          duration: 400,
          useNativeDriver: true,
        }),
        Animated.timing(imageTranslateX, {
          toValue: 0,
          duration: 460,
          useNativeDriver: true,
        }),
        Animated.timing(textTranslateX, {
          toValue: 0,
          duration: 600,
          useNativeDriver: true,
        }),
      ]).start();
    } else {
      Animated.parallel([
        Animated.timing(opacity, {
          toValue: 0,
          duration: 350,
          useNativeDriver: true,
        }),
        Animated.timing(imageTranslateX, {
          toValue: -150,
          duration: 450,
          useNativeDriver: true,
        }),
        Animated.timing(textTranslateX, {
          toValue: 105,
          duration: 550,
          useNativeDriver: true,
        }),
      ]).start(() => {
        setShouldRender(false);
      });
    }
  }, [visible, message]);
  const { height, width } = useWindowDimensions();
  const isLandscape = width > height;
  if (!shouldRender) return null;

  return (
    <>
      {isShowTop && (
        <View
          style={{
            height: Platform.OS === "ios" ? 16 : 6,
            width: "100%",
            backgroundColor:
              theme === "dark" ? "black" : ERP_COLOR_CODE.ERP_APP_COLOR,
            borderBottomLeftRadius: 12,
            borderBottomRightRadius: 12,
          }}
        ></View>
      )}

      <Animated.View
        style={[
          styles.container,
          theme === "dark" && { backgroundColor: "black" },
          { opacity },
        ]}
      >
        {isLandscape ? (
          <>
            <View style={{ flexDirection: "row" }}>
              <View
                style={{
                  width: "50%",
                  justifyContent: "center",
                  alignContent: "center",
                  alignItems: "center",
                }}
              >
                <Animated.Image
                  source={ERP_ICON.ERROR_ICON}
                  style={[
                    styles.errorImage,
                    { transform: [{ translateX: imageTranslateX }] },
                  ]}
                />
              </View>
              <View
                style={{
                  width: "50%",
                  justifyContent: "center",
                  alignContent: "center",
                  alignItems: "center",
                }}
              >
                <Animated.Text
                  style={[
                    styles.errorText,
                    { transform: [{ translateX: textTranslateX }] },
                  ]}
                >
                  {message}
                </Animated.Text>
              </View>
            </View>
          </>
        ) : (
          <>
            <Animated.Image
              source={ERP_ICON.ERROR_ICON}
              style={[
                styles.errorImage,
                { transform: [{ translateX: imageTranslateX }] },
              ]}
            />
            <Animated.Text
              style={[
                styles.errorText,
                { transform: [{ translateX: textTranslateX }] },
              ]}
            >
              {message}
            </Animated.Text>
          </>
        )}
      </Animated.View>
    </>
  );
};

export default ErrorMessage;

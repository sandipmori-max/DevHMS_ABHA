import React, { useState } from "react";
import { createBottomTabNavigator } from "@react-navigation/bottom-tabs";
import { DARK_COLOR, ERP_COLOR_CODE } from "../utils/constants";
import MenuTab from "../screens/dashboard/tabs/MenuTab/MenuTab";
import HomeScreen from "../screens/dashboard/tabs/home/HomeTab";
import ProfileTab from "../screens/dashboard/tabs/profile/ProfileTab";
import { useAppSelector } from "../store/hooks";
import AnimatedTabIcon from "../components/tab_icon/AnimatedTabIcon";
import { Platform } from "react-native";
import useTranslations from "../hooks/useTranslations";
import ConsentsScreen from "../abha/screens/Consents/ConsentsScreen";
 
const Tab = createBottomTabNavigator();

const TabNavigator = () => {
  const theme = useAppSelector((state) => state.theme.mode);
  const { appBottomMenuList } = useAppSelector((state) => state?.auth);
  const { t } = useTranslations();
  const [hidden, setHidden] = useState(false);
 
  const navigationItems = (appBottomMenuList || []).map((item) => ({
    name: item?.name,
    type: item?.code,
    icon: item?.iconname?.toLowerCase(),
    label: item?.name,
  }));

  // navigationItems.splice(3, 0, {
  //     name: "Consent",
  //     type: "C",
  //     icon: "analytics",
  //     label: "Consent",
  //   });

    
 const getComponent = (item) => {
  switch (item.name) {
    case "Home":
      return HomeScreen;
    case "Profile":
      return ProfileTab;
    case "Consent":
      return ConsentsScreen;
    default:
      return null;
  }
};
  const tabConfig = [
    {
      name: t("navigation.home"),
      component: HomeScreen,
      icon: "home",
      label: t("navigation.home"),
    },

    {
      name: t("navigation.profile"),
      component: ProfileTab,
      icon: "person",
      label: t("navigation.profile"),
    },
  ];

  return (
    <Tab.Navigator
      screenOptions={{
        headerShown: true,
        headerTitleAlign: "left",
        
        tabBarActiveTintColor:
          theme === "dark" ? "white" : ERP_COLOR_CODE.ERP_APP_COLOR,
        tabBarInactiveTintColor: 'gray',
        tabBarStyle: Platform.isTV ? {
         backgroundColor:
            theme === "dark" ? 'black' : ERP_COLOR_CODE.ERP_WHITE,
          borderTopWidth: 1,
          borderTopColor: '#E5E5EA',
          height: 46,
          paddingBottom: 5,
          paddingTop: 5,
          width: '28%',
          alignContent: 'center',
          alignItems: 'center',
          alignSelf: 'center',
         } : {
          display: hidden ? "none" : "flex",
          backgroundColor:
            theme === "dark" ? 'black' : ERP_COLOR_CODE.ERP_WHITE,
          height: Platform.OS === "ios" ? theme === "dark" ? 70 : 60 : 70,
          paddingBottom: 5,
          paddingTop: 5,
        },
        tabBarShowLabel : !Platform.isTV,
        headerStyle: {
          backgroundColor:
            theme === "dark" ? 'black' : ERP_COLOR_CODE.ERP_APP_COLOR,
            height: Platform.OS === 'android' ? 48 : undefined
        },
        headerTintColor: "white", 
      }}
    >
      {navigationItems.length > 0 &&
        navigationItems.map((item, index) => {
          const Component = getComponent(item);

          return (
            <Tab.Screen
              key={index}
              name={item.name}
              children={
                Component
                  ? () => <Component hideTab={hidden} setHideTab={setHidden} />
                  : () => (
                      <MenuTab
                        hideTab={hidden}
                        setHideTab={setHidden}
                        type={item.type}
                        headerText={item.label}
                        searchPlaceholder={`Search ${item.label}`}
                      />
                    )
              }
              options={{
                tabBarLabel: item.label,
                title: item.label,
                tabBarLabelStyle: {
                  fontSize: 12,
                  fontWeight: "500",
                  marginTop: 8,
                },
                tabBarIcon: ({ color, size, focused }) => (
                  <AnimatedTabIcon
                    name={item.icon}
                    color={color}
                    size={size}
                    focused={focused}
                  />
                ),
              }}
            />
          );
        })}
      {navigationItems.length === 0 &&
        tabConfig.map((item, index) => {
          const Component = getComponent(item);

          return (
            <Tab.Screen
              key={index}
              name={item.name}
     
              children={
                Component
                  ? () => <Component hideTab={hidden} setHideTab={setHidden} />
                  : () => (
                      <MenuTab
                        hideTab={hidden}
                        setHideTab={setHidden}
                        type={item.type}
                        headerText={item.label}
                        searchPlaceholder={`Search ${item.label}`}
                      />
                    )
              }
              options={{
                tabBarLabel: item.label,
                title: item.label,
                
                tabBarLabelStyle: {
                  fontSize: 12,
                  fontWeight: "500",
                  marginTop: 8,
                  color: theme === "dark" ? "white" : 'black',
                },
                tabBarIcon: ({ color, size, focused }) => (
                  <AnimatedTabIcon
                    name={item.icon}
                    color={color}
                    size={size}
                    focused={focused}
                  />
                ),
              }}
            />
          );
        })}
    </Tab.Navigator>
  );
};

export default TabNavigator;

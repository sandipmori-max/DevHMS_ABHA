import { Alert, Platform } from "react-native";
import { generateGUID } from "../../utils/helpers";
import { getActiveAccount, getDBConnection } from "../../utils/sqlite";
import apiClient from "./config";
import {
  DevERPResponse,
  LoginRequest,
  LoginResponse,
  TokenRequest,
  TokenResponse,
  MenuResponse,
  DashboardResponse,
  ListDataResponse,
  AttendanceResponse,
} from "./types";
import AsyncStorage from "@react-native-async-storage/async-storage";
import NetInfo from "@react-native-community/netinfo";

class DevERPService {
  private readonly baseUrl = "/devws";
  private link: string = "";
  private token: string = "";
  private tokenValidTill: string = "";
  private appid: string = generateGUID();
  private device: string = "";

  private async checkNetwork(): Promise<boolean> {
    const netInfo = await NetInfo.fetch();
    return !!(netInfo.isConnected && netInfo.isInternetReachable !== false);
  }

  private async ensureAuthToken(forceRefresh = false) {
    if (!forceRefresh && this.token && this.tokenValidTill) {
      if (new Date(this.tokenValidTill) > new Date()) return this.token;
    }

    const storedToken = await AsyncStorage.getItem("erp_token");
    const storedTokenValidTill = await AsyncStorage.getItem(
      "erp_token_valid_till",
    );

    if (
      storedToken &&
      storedTokenValidTill &&
      new Date(storedTokenValidTill) > new Date()
    ) {
      this.token = storedToken;
      this.tokenValidTill = storedTokenValidTill;
      return this.token;
    }

    return this.getAuth();
  }

  private async apiCall<T>(endpoint: string, payload: any): Promise<any> {
    try {
      const isConnected = await this.checkNetwork();

      if (!isConnected) {
        
        return;
      }

      await this.ensureAuthToken();

      const response = await apiClient.post<T>(
        `${this.link}${endpoint}`,
        payload,
      );
      if (
        (response as any).data?.success === 0 &&
        (response as any).data?.message?.includes("Invalid Token")
      ) {
        await this.ensureAuthToken(true);
        const retryResponse = await apiClient.post<T>(
          `${this.link}${endpoint}`,
          {
            ...payload,
            token: this.token,
          },
        );
        return retryResponse.data;
      }

      return response.data;
    } catch (error) {
      throw error;
    }
  }

  async getAppLink(code: string): Promise<any> {
    const isConnected = await this.checkNetwork();

    if (!isConnected) {
      
      return;
    }

    const response = await apiClient.post<DevERPResponse>(
      `${this.baseUrl}/appcode.aspx/getLink`,
      {
        code,
      },
    );
    if (response.data.success === 1 && response.data.link) {
      if (Platform.OS !== "ios" && response.data.link.startsWith("https://")) {
        this.link = response.data.link.replace(/^https:\/\//i, "http://");
      } else {
        this.link = response.data.link;
      }
      await AsyncStorage.setItem("erp_link", this.link);
    }
    console.log("this.link", this.link)
    return response.data;
  }

  async validateCompanyCode(code: string) {
    try {
      const response = await this.getAppLink(code);
      return response.success === 1
        ? {
          isValid: true,
          appName: response?.name,
          appUrl: response?.link,
          message: "Company code validated successfully",
          response: response,
        }
        : { isValid: false, message: "Invalid company code" };
    } catch (e) {
      return { isValid: false, message: "Failed to validate company code" };
    }
  }

  async loginToERP(credentials: {
    user: string;
    pass: string;
    firebaseid?: string;
  }): Promise<any> {
    console.error(" 👈 👈 👈 Login credentials received: 👈👈👈👈 ---- -- - -- - - - - -", credentials); // 👈 added log
    const isConnected = await this.checkNetwork();

      if (!isConnected) {
        
        return;
      }
    const app_id = generateGUID();
    await AsyncStorage.setItem("appid", app_id);
    this.appid = app_id;
    this.link = (await AsyncStorage.getItem("erp_link")) || this.link;

    const loginData: LoginRequest = {
      user: credentials.user,
      pass: credentials.pass,
      appid: app_id,
      firebaseid: credentials.firebaseid || "",
      device: this.device,
    };
    try {
      const response = await apiClient.post<LoginResponse>(
        `${this.link}msp_api.aspx/setAppID`,
        loginData,
      );
      return { ...response.data, app_id: app_id };
    } catch (error) {
      return {
        success: 0,
        message: error?.data?.message || "Something went wong",
      };
    }
  }

  async getAuth(): Promise<any> {
    const isConnected = await this.checkNetwork();
      if (!isConnected) {
         
        return;
      }
    await new Promise(res => setTimeout(res, 600));
    const tokenData: TokenRequest = { appid: this.appid, device: this.device };
    console.log("tokenData", tokenData)
    const response = await apiClient.post<TokenResponse>(
      `${this.link}msp_api.aspx/getAuth`,
      tokenData,
    );
    console.log("response", response?.data?.success)
    if (`${response?.data?.success}` !== '1') {
      return 'token_expired'
    }

    this.token = response?.data?.token || "";
    this.tokenValidTill = response?.data?.validTill || "";
    await AsyncStorage.multiSet([
      ["erp_token", this.token],
      ["erp_token_valid_till", this.tokenValidTill],
    ]);

    try {
      const db = await getDBConnection();
      const tableCheckResult = await db.executeSql(
        `SELECT name FROM sqlite_master WHERE type='table' AND name=?`,
        ["erp_accounts"],
      );
      if (tableCheckResult[0].rows.length > 0) {
        const activeAccount = await getActiveAccount(db);

        this.token = response.data.token || "";
        if (activeAccount) {
          const updatedUser = {
            ...activeAccount.user,
            token: response.data.token,
            tokenValidTill: response.data.validTill,
          };
          await db.executeSql(
            `UPDATE erp_accounts SET user_json = ? WHERE id = ?`,
            [JSON.stringify(updatedUser), activeAccount.id],
          );
        }
      }
    } catch (err) { }

    return this.token;
  }

  getMenu() {
    return this.apiCall<MenuResponse>("msp_api.aspx/getMenu", {
      token: this.token,
    }).then((res) => JSON.stringify(res));
  }

  getAppMenu() {
    return this.apiCall<MenuResponse>("msp_api.aspx/getAppConfig", {
      token: this.token,
    }).then((res) => JSON.stringify(res));
  }

  getDashboard(
    branch: string,
    type: string,
    fd: string,
    td: string,
  ): Promise<DashboardResponse> {
    console.log("this.token +++++++ ++ ++ + ++ + + + + +", this.token)
    return this.apiCall<DashboardResponse>("msp_api.aspx/getDB", {
      token: this.token,
      branch,
      type,
      fd,
      td,
    });
  }

  getPage(page: string, id: string) {
    return this.apiCall<any>("msp_api.aspx/getPage", {
      token: this.token,
      page,
      id,
    });
  }

  getListData(page: string, fd: string, td: string, param: string, branch: string) {
    return this.apiCall<ListDataResponse>("msp_api.aspx/getListData", {
      token: this.token,
      page,
      fd,
      td,
      param,
      branch
    }).then((res) =>
      JSON.stringify({ data: res.data, config: res.config || [] }),
    );
  }

  getConfigData(page: string) {
    return this.apiCall<ListDataResponse>("msp_api.aspx/getListConfig", {
      token: this.token,
      page,
    }).then((res) => {
      console.log("API Response (getConfigData):", res); // 👈 added log

      return JSON.stringify({
        data: res,
        config: res || [],
      });
    });
  }

  markAttendance(rawData: any, isPunchIn: boolean, user: any, id: any) {
    const pageType = isPunchIn ? "punchin" : "punchout";
    const punchOutData = {
      id: id,
      employeeid: user.id,
      outimage: rawData.imageBase64,
      outremarks: rawData?.remark || "",
      outlocation: `${rawData?.latitude},${rawData?.longitude}`,
    };

    const punchInData = {
      id: "0",
      employeeid: user.id.toString(),
      inimage: rawData.imageBase64,
      inremarks: rawData?.remark || "",
      inlocation: `${rawData?.latitude.toString()},${rawData?.longitude.toString()}`,
    };

    return this.apiCall<AttendanceResponse>(`msp_api.aspx/pageSave`, {
      token: this.token,
      page: pageType,
      data: JSON.stringify(isPunchIn ? punchInData : punchOutData),
    });
  }

  savePage(page: string, id: string, rawData: any) {

    console.log("sabe page -------- ", page)
    console.log("rawData  page -------- ", {
      token: this.token,
      page,
      data: JSON.stringify(rawData),
    })

    return this.apiCall<any>(`msp_api.aspx/pageSave`, {
      token: this.token,
      page,
      data: JSON.stringify(rawData),
    });
  }

  getDDL(dtlid: string, where: string) {
    return this.apiCall<any>("msp_api.aspx/getDDL", {
      token: this.token,
      dtlid,
      where,
    });
  }

  getAjax(dtlid: string, where: string, search: string) {
    return this.apiCall<any>("msp_api.aspx/getAjax", {
      token: this.token,
      dtlid,
      where,
      search,
    });
  }

  getLastPunchIn() {
    return this.apiCall<any>("msp_api.aspx/getLastPunchIn", {
      token: this.token,
    });
  }

  getLastPunchList(id: any, fd: any, td: any) {
    return this.apiCall<any>("msp_api.aspx/getListData", {
      token: this.token,
      page: "PunchIn",
      id,
      fd: fd,
      td: td,
    });
  }

  async handlePageAction(
    action: string,
    id: string,
    remarks: string,
    page: string,
  ) {
    return this.apiCall<any>(`msp_api.aspx/${action}`, {
      token: this.token,
      id,
      remarks,
      page,
    });
  }

  async handleDeleteAction(id: string, page: string, remarks: string) {
    return this.apiCall<any>(`msp_api.aspx/pageDelete`, {
      token: this.token,
      id,
      page,
      remarks,
    });
  }

  async syncLocation(token: string, location: string) {
    return this.apiCall<any>(`msp_api.aspx/syncLocation`, {
      token: token,
      location: location,
    });
  }

  async initialize() {
    this.link = (await AsyncStorage.getItem("erp_link")) || "";
    this.token = (await AsyncStorage.getItem("erp_token")) || "";
    this.tokenValidTill =
      (await AsyncStorage.getItem("erp_token_valid_till")) || "";
    this.appid = (await AsyncStorage.getItem("erp_appid")) || "";
    this.device = (await AsyncStorage.getItem("device")) || "";
  }

  async clearData() {
    this.link = "";
    this.token = "";
    this.tokenValidTill = "";
    this.appid = "";
    await AsyncStorage.multiRemove([
      "erp_link",
      "erp_token",
      "erp_token_valid_till",
      "erp_appid",
    ]);
  }

  setToken(token: string) {
    console.log("Setting new token:  👈 added log ------------------- ", token);
    this.token = token;
    AsyncStorage.setItem("erp_token", token);
  }

  setDevice(device: string) {
    AsyncStorage.setItem("device", device);

    this.device = device;
  }

  setAppId(appId: string) {
    AsyncStorage.setItem("erp_appid", appId);
    this.appid = appId;
  }
}

export default new DevERPService();

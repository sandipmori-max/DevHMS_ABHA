import { Platform, StyleSheet } from "react-native";
import { ERP_COLOR_CODE } from "../../../utils/constants";

export const styles = StyleSheet.create({
  input: {
    borderWidth: 1,
    borderColor: ERP_COLOR_CODE.ERP_BORDER_LINE,
    borderRadius: 6,
    padding: 10,
  },
  overlay: {
    flex: 1,
    backgroundColor: "rgba(0,0,0,0.35)",
    justifyContent: "flex-end",
  },

  sheet: {
    backgroundColor: "#fff",
    borderTopLeftRadius: 16,
    borderTopRightRadius: 16,
    paddingBottom: 20,
  },

  header: {
    height: 50,
    paddingHorizontal: 16,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
  },

  headerTitle: {
    fontSize: 16,
    fontWeight: "600",
    color: "#111827",
  },

  doneText: {
    fontSize: 16,
    fontWeight: "600",
    color: "#2563eb", // iOS blue
  },

  divider: {
    height: 1,
    backgroundColor: "#e5e7eb",
  },

  picker: {
    height: 220,
  },
  center: { flex: 1, justifyContent: "center", alignItems: "center" },

  label: {
    width:'100%',
    fontSize: 14,
    marginBottom: 6,
    fontWeight: "600",
  },
  textInput: {
    borderWidth: 1,
    borderColor: ERP_COLOR_CODE.ERP_BORDER_LINE,
    borderRadius: 6,
    padding: 8,
    backgroundColor: ERP_COLOR_CODE.ERP_WHITE,
    color: "black",
  },
    pickerBox1: {
    borderWidth: 1,
    borderColor: ERP_COLOR_CODE.ERP_BORDER_LINE,
    borderRadius: 6,
    padding: 6,
    backgroundColor: ERP_COLOR_CODE.ERP_WHITE,
    flexDirection: "row",
    justifyContent: "space-between",
    alignContent: "center",
    alignItems: "center",
  },
  pickerBox: {
    borderWidth: 1,
    borderColor: ERP_COLOR_CODE.ERP_BORDER_LINE,
    borderRadius: 6,
    paddingHorizontal: 6,
    paddingVertical: 4,
    backgroundColor: ERP_COLOR_CODE.ERP_WHITE,
    flexDirection: "row",
    justifyContent: "space-between",
    alignContent: "center",
    alignItems: "center",
  },
  dropdownCard: {
    marginTop: 4,
    borderRadius: 8,
    borderWidth: 1,
    borderColor: ERP_COLOR_CODE.ERP_BORDER_LINE,
    backgroundColor: ERP_COLOR_CODE.ERP_WHITE,
    overflow: "hidden",
    elevation: 3,
  },
  option: {
    padding: 12,
    borderBottomWidth: 1,
    borderBottomColor: ERP_COLOR_CODE.ERP_eee,
    flexDirection: "row",
    justifyContent: "space-between",
    alignContent: "center",
    alignItems: "center",
  },
  disabledBox: {
    borderWidth: 1,
    borderColor: ERP_COLOR_CODE.ERP_BORDER_LINE,
    borderRadius: 6,
    padding: 8,
    backgroundColor: "#f1f1f1",
    flexDirection:'row',
    justifyContent:'space-between',
    width:'100%'
  },
  dateBox: {
    borderWidth: 1,
    borderColor: ERP_COLOR_CODE.ERP_BORDER_LINE,
    borderRadius: 6,
    padding: 6,
    backgroundColor: ERP_COLOR_CODE.ERP_WHITE,
    flexDirection: "row",
    justifyContent: "space-between",
    alignContent: "center",
    alignItems: "center",
  },
  overlay: {
    flex: 1,
    justifyContent: "flex-end",
    backgroundColor: "rgba(0,0,0,0.4)",
  },
  bottomSheet: {
    backgroundColor: "white",
    padding: 16,
    borderTopLeftRadius: 20,
    borderTopRightRadius: 20,
    maxHeight: "50%",
    marginVertical: 4,
  },
  title: {
    fontSize: 16,
    fontWeight: "600",
  },
  errorText: {
    color: ERP_COLOR_CODE.ERP_ERROR,
    marginBottom: 6,
  },
  closeBtn: {
    marginTop: 16,
    backgroundColor: "black",
    padding: 12,
    borderRadius: 8,
    alignItems: "center",
  },
});

import { Platform, StyleSheet } from "react-native";
import { ERP_COLOR_CODE } from "../../../utils/constants";

export const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: ERP_COLOR_CODE.ERP_WHITE,
  },
  header: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    padding: 16,
    backgroundColor: ERP_COLOR_CODE.ERP_WHITE,
    borderBottomWidth: 1,
    borderBottomColor: ERP_COLOR_CODE.ERP_e0e0e0,
  },
  backBtn: {
    padding: 8,
  },
  backIcon: {
    fontSize: 22,
    color: ERP_COLOR_CODE.ERP_222,
  },
  headerTitle: {
    fontSize: 20,
    fontWeight: "bold",
    color: ERP_COLOR_CODE.ERP_222,
  },
  profileCard: {
    backgroundColor: ERP_COLOR_CODE.ERP_WHITE,
    margin: 16,
    padding: 16,
    borderRadius: 12,
    elevation: 2,
    shadowColor: ERP_COLOR_CODE.ERP_BLACK,
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
  },
  profileHeader: {
    flexDirection: "row",
    alignItems: "center",
  },
  profileAvatar: {
    width: 60,
    height: 60,
    borderRadius: 30,
    backgroundColor: ERP_COLOR_CODE.ERP_f0f0f0,
    alignItems: "center",
    justifyContent: "center",
    marginRight: 16,
  },
  avatarText: {
    fontSize: 32,
  },
  profileInfo: {
    flex: 1,
  },
  profileName: {
    fontSize: 18,
    fontWeight: "bold",
    color: ERP_COLOR_CODE.ERP_222,
    marginBottom: 2,
  },
  profileEmail: {
    fontSize: 14,
    color: ERP_COLOR_CODE.ERP_666,
    marginBottom: 2,
  },
  profileRole: {
    fontSize: 12,
    color: ERP_COLOR_CODE.ERP_999,
  },
  editProfileBtn: {
    paddingHorizontal: 16,
    paddingVertical: 8,
    backgroundColor: "#2196F3",
    borderRadius: 20,
  },
  editProfileText: {
    fontSize: 14,
    color: ERP_COLOR_CODE.ERP_WHITE,
    fontWeight: "600",
  },
  sectionContainer: {
    backgroundColor: ERP_COLOR_CODE.ERP_WHITE,
    marginHorizontal: 10,
    marginVertical: Platform.OS === 'android' ? 6 : 8,
    borderRadius: Platform.OS === 'android' ? 6 : 8,
    overflow: "hidden",
    borderWidth: 0.6,
    borderColor: ERP_COLOR_CODE.ERP_BORDER_LINE,
  },
  sectionTitle: {
    fontSize: 16,
    fontWeight: "600",
    color: ERP_COLOR_CODE.ERP_222,
    padding: Platform.OS === 'android' ? 6 : 8, 
    backgroundColor: "#f9f9f9",
  },
  settingCard: {
    padding: Platform.OS === 'android' ?  12 : 14,
    borderBottomWidth: 1,
    borderBottomColor: ERP_COLOR_CODE.ERP_f0f0f0,
  },
  settingHeader: {
    flexDirection: "row",
    alignItems: "center",
  },
  settingIcon: {
    width: Platform.OS === 'android' ? 36 : 40,
    height: Platform.OS === 'android' ? 36 : 40,
    borderRadius: Platform.OS === 'android' ? 8 :10,
    backgroundColor: ERP_COLOR_CODE.ERP_f0f0f0,
    alignItems: "center",
    justifyContent: "center",
    marginRight: 12,
  },
  iconText: {
    fontSize: 18,
  },
  settingInfo: {
    flex: 1,
  },
  settingTitle: {
    fontSize: 16,
    fontWeight: "500",
    color: ERP_COLOR_CODE.ERP_222,
    marginBottom: 2,
  },
  settingSubtitle: {
    fontSize: 14,
    color: ERP_COLOR_CODE.ERP_666,
  },
  arrowIcon: {
    fontSize: 20,
    color: ERP_COLOR_CODE.ERP_999,
  },
  scrollContainer: {
    flex: 1,
  },
  scrollContent: {
    paddingBottom: 20,
  },
  bottomSpacing: {
    height: 20,
  },
});

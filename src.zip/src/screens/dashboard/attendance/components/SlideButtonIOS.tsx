import React from "react";
import {
  View,
  Text,
  TouchableOpacity,
  ActivityIndicator,
  StyleSheet,
  Dimensions,
  useWindowDimensions,
} from "react-native";
import MaterialIcons from "@react-native-vector-icons/material-icons";
import { ERP_COLOR_CODE } from "../../../../utils/constants";
import useTranslations from "../../../../hooks/useTranslations";
import { useAppSelector } from "../../../../store/hooks";

const SLIDE_WIDTH = Dimensions.get("screen").width - 30;
const SLIDER_SIZE = 44;

interface Props {
  onSlideSuccess: () => void;
  label: string;
  successColor?: string;
  loading?: boolean;
  completed?: boolean;
}

const SlideButtonIOS: React.FC<Props> = ({
  onSlideSuccess,
  label,
  successColor = ERP_COLOR_CODE.ERP_APP_COLOR,
  loading = false,
  completed = false,
}) => {
  const { t } = useTranslations();
  const { height, width } = useWindowDimensions();
  const isLandscape = width > height;
    const theme = useAppSelector(state => state?.theme.mode);
  
  return (
    <TouchableOpacity
      onPress={() => {
        if (!loading && !completed) onSlideSuccess();
      }}
      style={styles.container}
      activeOpacity={0.7}
    >
      <View
        style={[
          styles.sliderContainer,
          {
            borderColor: theme === "dark" ? "white" : successColor,
            backgroundColor: theme === "dark" ? "black" : successColor,
          },

          isLandscape
            ? {
                width: "100%",
              }
            : {
                width: width - 20,
              },
        ]}
      >
        {loading ? (
          <ActivityIndicator color={ERP_COLOR_CODE.ERP_WHITE} />
        ) : (
          <View style={{ flexDirection: "row" ,
          gap: 8,
          justifyContent:'center', alignContent:'center', alignItems:'center'}}>
            <MaterialIcons
              name={'touch-app'}
              color="white"
              size={22}
            />
            <Text style={styles.label}>
              {loading
                ? t("text.text22")
                : completed
                ? t("text.text23").toUpperCase()
                : label.toUpperCase()}
            </Text>
          </View>
        )}

        {/* <View style={[styles.slider, { backgroundColor: successColor }]}>
          {loading ? (
            <ActivityIndicator color={ERP_COLOR_CODE.ERP_WHITE} />
          ) : (
            <MaterialIcons
              name={completed ? 'task-alt' : 'keyboard-double-arrow-right'}
              color="white"
              size={22}
            />
          )}
        </View> */}
      </View>
    </TouchableOpacity>
  );
};

const styles = StyleSheet.create({
  container: {
    alignItems: "center",
    marginVertical: 20,
  },
  sliderContainer: {
    width: SLIDE_WIDTH,
    height: SLIDER_SIZE,
    borderRadius: 6,
    borderWidth: 2,
    justifyContent: "center",
    overflow: "hidden",
  },
  label: { 
    fontWeight: "600",
    color: ERP_COLOR_CODE.ERP_WHITE,
  },
  slider: {
    width: SLIDER_SIZE,
    height: SLIDER_SIZE,
    borderRadius: 6,
    justifyContent: "center",
    alignItems: "center",
    position: "absolute",
    left: 0,
    top: 0,
  },
});

export default SlideButtonIOS;
